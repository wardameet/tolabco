--
-- PostgreSQL database dump
--

\restrict oKQ58APi6l4qMN64vVdhhdSsRA6Y0IXIJ6eBsKdu5UfOmnI70BlSgJ0fb9fXwF2

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: studenthub_user
--

CREATE TYPE public."Role" AS ENUM (
    'student',
    'employer',
    'admin',
    'outlet'
);


ALTER TYPE public."Role" OWNER TO studenthub_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid,
    student_id uuid,
    status character varying(20) DEFAULT 'pending'::character varying,
    applied_at timestamp without time zone DEFAULT now(),
    employer_contacted_at timestamp without time zone,
    CONSTRAINT applications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'viewed'::character varying, 'contacted'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.applications OWNER TO postgres;

--
-- Name: employers; Type: TABLE; Schema: public; Owner: studenthub_user
--

CREATE TABLE public.employers (
    user_id uuid NOT NULL,
    company_name text NOT NULL,
    company_city text
);


ALTER TABLE public.employers OWNER TO studenthub_user;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    employer_id uuid,
    title character varying(255) NOT NULL,
    description text,
    job_type character varying(50),
    location_city character varying(100),
    is_remote boolean DEFAULT false,
    salary_range character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: redemptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redemptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    voucher_id uuid,
    student_id uuid,
    redeemed_at timestamp without time zone DEFAULT now(),
    outlet_verified_by uuid
);


ALTER TABLE public.redemptions OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: studenthub_user
--

CREATE TABLE public.students (
    user_id uuid NOT NULL,
    full_name text NOT NULL,
    date_of_birth timestamp(3) without time zone,
    city text,
    profession_category text,
    skills text[] DEFAULT ARRAY[]::text[],
    video_cv_url text,
    cv_text text,
    unique_link text,
    verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.students OWNER TO studenthub_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: studenthub_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    phone text,
    password_hash text,
    role public."Role" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO studenthub_user;

--
-- Name: verification_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    student_id uuid,
    id_photo_url character varying(500),
    selfie_url character varying(500),
    status character varying(20) DEFAULT 'pending'::character varying,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT verification_queue_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.verification_queue OWNER TO postgres;

--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vouchers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    outlet_id uuid,
    title character varying(255) NOT NULL,
    description text,
    discount_percent integer,
    qr_code_url character varying(500),
    start_date date,
    end_date date,
    max_redemptions integer,
    redemption_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vouchers OWNER TO postgres;

--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.applications (id, job_id, student_id, status, applied_at, employer_contacted_at) FROM stdin;
\.


--
-- Data for Name: employers; Type: TABLE DATA; Schema: public; Owner: studenthub_user
--

COPY public.employers (user_id, company_name, company_city) FROM stdin;
4788e92d-02ac-4ab4-898d-7f5c945c97c0	Tech Corp	\N
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, employer_id, title, description, job_type, location_city, is_remote, salary_range, is_active, created_at) FROM stdin;
530415cb-33fb-4aae-ae93-4104b32fc646	4788e92d-02ac-4ab4-898d-7f5c945c97c0	New Test Job	Test	part_time	Cairo	f	\N	t	2026-05-07 00:52:51.516108
\.


--
-- Data for Name: redemptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redemptions (id, voucher_id, student_id, redeemed_at, outlet_verified_by) FROM stdin;
64a76db2-cfb0-4986-bccd-d56a671cbd8a	d5040693-9711-49ec-8268-8abf5ecba516	45dc734e-fcb3-480c-9fa7-2241dc7ac801	2026-05-07 11:02:24.280557	\N
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: studenthub_user
--

COPY public.students (user_id, full_name, date_of_birth, city, profession_category, skills, video_cv_url, cv_text, unique_link, verified) FROM stdin;
45dc734e-fcb3-480c-9fa7-2241dc7ac801	Sara Ali	\N	Cairo	Sales	{communication,teamwork}	https://s3.eu-central-3.ionoscloud.com/studenthub-video-cv/students/45dc734e-fcb3-480c-9fa7-2241dc7ac801/cv.mp4?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=EEAAAAFcrPNWYXpK95LYwH3SCl-L-y2SmHkVWGiUCMhobMBF2gCo2BYCRZecAAAAAAJFl5w-OKR__hnOpS51xf39_FAy%2F20260506%2Feu-central-3%2Fs3%2Faws4_request&X-Amz-Date=20260506T232155Z&X-Amz-Expires=604800&X-Amz-Signature=0c964e3140c624bff2e6722673ec47158ffeb981182b756ad7eea0f2ee05e94d&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject	**Motivated sales-oriented student with strong communication and teamwork skills, based in Cairo. Demonstrates a proven ability to collaborate effectively in fast-paced environments while engaging customers with clarity and confidence. Seeking an entry-level sales role to apply interpersonal strengths and develop practical experience in client relations and retail operations.**	sara-ali-558522	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: studenthub_user
--

COPY public.users (id, email, phone, password_hash, role, is_active, created_at, updated_at) FROM stdin;
45dc734e-fcb3-480c-9fa7-2241dc7ac801	student2@example.com	\N	$2b$10$YNrFu12BtMRpcI7Shxn8puTO.9dOT.p3BJo1rN96h/WcVaQFitXSq	student	t	2026-05-06 21:57:00.156	2026-05-06 21:57:00.156
4788e92d-02ac-4ab4-898d-7f5c945c97c0	employer1@example.com	\N	$2b$10$Rfausi5Y7BegmtLcNv3h2eVVilGxIw8U7oERTa4IdkNM/uwYV.FOW	employer	t	2026-05-06 22:02:56.261	2026-05-06 22:02:56.261
c8040706-2cd0-4737-b961-0f6bb54c6972	admin@studenthub.com	\N	$2b$10$woInmgChEQMdhMvv2Qd4W.ETDyV6OwZTMGlB5QL.PrF9tJnZdapX2	admin	t	2026-05-06 23:30:49.264	2026-05-06 23:30:49.264
7d7b0203-c8d4-4d83-af27-00f4acfcc6bf	outlet@example.com	\N	$2b$10$r6beggRHMXgoelIC8yz7EOkvnlf5Kvx5s8jPKEri.BlmMiF/Ndqq2	outlet	t	2026-05-07 10:58:41.544	2026-05-07 10:58:41.544
c44c74ab-e3b7-4d16-85c6-bdea8155a61c	outlet2@example.com	\N	$2b$10$PJOvZ/mwdPOdEEc6/.6j7uZkisgV4Rg241e85Zj1LjWABOF50HkNa	outlet	t	2026-05-07 11:12:42.909	2026-05-07 11:12:42.909
\.


--
-- Data for Name: verification_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_queue (id, student_id, id_photo_url, selfie_url, status, reviewed_by, reviewed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vouchers (id, outlet_id, title, description, discount_percent, qr_code_url, start_date, end_date, max_redemptions, redemption_count, is_active, created_at) FROM stdin;
d5040693-9711-49ec-8268-8abf5ecba516	7d7b0203-c8d4-4d83-af27-00f4acfcc6bf	Student Special	15% off on all items	15	\N	2026-05-07	2026-06-06	\N	1	t	2026-05-07 10:59:03.432827
\.


--
-- Name: applications applications_job_id_student_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_job_id_student_id_key UNIQUE (job_id, student_id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: employers employers_pkey; Type: CONSTRAINT; Schema: public; Owner: studenthub_user
--

ALTER TABLE ONLY public.employers
    ADD CONSTRAINT employers_pkey PRIMARY KEY (user_id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: redemptions redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: studenthub_user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: studenthub_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_queue verification_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_queue
    ADD CONSTRAINT verification_queue_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: students_unique_link_key; Type: INDEX; Schema: public; Owner: studenthub_user
--

CREATE UNIQUE INDEX students_unique_link_key ON public.students USING btree (unique_link);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: studenthub_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: studenthub_user
--

CREATE UNIQUE INDEX users_phone_key ON public.users USING btree (phone);


--
-- Name: applications applications_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: applications applications_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(user_id) ON DELETE CASCADE;


--
-- Name: employers employers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studenthub_user
--

ALTER TABLE ONLY public.employers
    ADD CONSTRAINT employers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: jobs jobs_employer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_employer_id_fkey FOREIGN KEY (employer_id) REFERENCES public.users(id);


--
-- Name: redemptions redemptions_outlet_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_outlet_verified_by_fkey FOREIGN KEY (outlet_verified_by) REFERENCES public.users(id);


--
-- Name: redemptions redemptions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(user_id);


--
-- Name: redemptions redemptions_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id);


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: studenthub_user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: verification_queue verification_queue_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_queue
    ADD CONSTRAINT verification_queue_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: verification_queue verification_queue_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_queue
    ADD CONSTRAINT verification_queue_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(user_id);


--
-- Name: vouchers vouchers_outlet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_outlet_id_fkey FOREIGN KEY (outlet_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO studenthub_user;


--
-- Name: TABLE applications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.applications TO studenthub_user;


--
-- Name: TABLE jobs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.jobs TO studenthub_user;


--
-- Name: TABLE redemptions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.redemptions TO studenthub_user;


--
-- Name: TABLE verification_queue; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.verification_queue TO studenthub_user;


--
-- Name: TABLE vouchers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.vouchers TO studenthub_user;


--
-- PostgreSQL database dump complete
--

\unrestrict oKQ58APi6l4qMN64vVdhhdSsRA6Y0IXIJ6eBsKdu5UfOmnI70BlSgJ0fb9fXwF2

