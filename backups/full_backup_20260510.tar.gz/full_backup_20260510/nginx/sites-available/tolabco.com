server {
    listen 80;
    server_name tolabco.com www.tolabco.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name tolabco.com www.tolabco.com;

    ssl_certificate /etc/letsencrypt/live/tolabco.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/tolabco.com/privkey.pem;

    # Frontend static files (production build)
    root /var/www/studenthub/frontend/dist;
    index index.html;

    # API proxy – strip /api prefix
    location /api/ {
        rewrite ^/api/(.*) /$1 break;
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # React router fallback – send everything else to index.html
    location / {
        try_files $uri $uri/ /index.html;
    }
}
